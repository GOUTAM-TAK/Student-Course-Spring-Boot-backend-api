package com.app.exception;

public class CDACException extends Exception {

	
	public CDACException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
